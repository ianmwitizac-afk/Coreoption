export default function App() {
  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <nav className="border-b border-slate-800 p-6 flex justify-between">
        <h1 className="text-2xl font-bold">CoreOption</h1>
        <button className="bg-blue-600 px-4 py-2 rounded-xl">Get Started</button>
      </nav>

      <header className="p-10 text-center">
        <h2 className="text-5xl font-black">Trade Smarter</h2>
        <p className="text-slate-400 mt-4">
          Modern crypto & forex demo trading platform
        </p>
      </header>

      <section className="grid md:grid-cols-3 gap-6 p-10">
        <div className="bg-slate-900 p-6 rounded-2xl">Fast Trading Engine</div>
        <div className="bg-slate-900 p-6 rounded-2xl">Secure Wallet System</div>
        <div className="bg-slate-900 p-6 rounded-2xl">Referral System</div>
      </section>
    </div>
  )
}
